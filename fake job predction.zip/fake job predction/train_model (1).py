import pandas as pd
import re
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from imblearn.over_sampling import SMOTE
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from scipy.sparse import hstack
import joblib

# Download NLTK data
nltk.download('stopwords')
nltk.download('punkt')
stop_words = set(stopwords.words('english'))

# Text cleaning function
def clean_text(text):
    if isinstance(text, str):
        text = re.sub(r'[^a-zA-Z\s]', '', text).lower()
        tokens = word_tokenize(text)
        tokens = [word for word in tokens if word not in stop_words]
        return ' '.join(tokens)
    return ''

# Load dataset
data = pd.read_csv('fake_job_postings.csv')


# Handle missing values
text_columns = ['title', 'description', 'requirements', 'company_profile']
for col in text_columns:
    data[col] = data[col].fillna('')

# Combine text columns
data['combined_text'] = (data['title'] + ' ' + 
                        data['description'] + ' ' + 
                        data['requirements'] + ' ' + 
                        data['company_profile'])

# Clean text
data['combined_text'] = data['combined_text'].apply(clean_text)

# Feature engineering
tfidf = TfidfVectorizer(max_features=5000, ngram_range=(1, 2))
X_text = tfidf.fit_transform(data['combined_text'])
data['text_length'] = data['combined_text'].apply(len)
X_additional = data[['text_length']].values
X = hstack([X_text, X_additional])
y = data['fraudulent']

# Handle class imbalance
smote = SMOTE(random_state=42)
X_balanced, y_balanced = smote.fit_resample(X, y)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X_balanced, y_balanced, test_size=0.2, random_state=42)

# Train model
model = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
model.fit(X_train, y_train)

# Save model and vectorizer
joblib.dump(model, 'fake_job_model.pkl')
joblib.dump(tfidf, 'tfidf_vectorizer.pkl')

print("Model and vectorizer saved successfully!")