import streamlit as st
import re
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

# Download NLTK data
try:
    nltk.download('stopwords', quiet=True)
    nltk.download('punkt', quiet=True)
    nltk.download('punkt_tab', quiet=True)
except Exception as e:
    st.error(f"Failed to download NLTK resources: {str(e)}. Run: import nltk; nltk.download('punkt_tab')")
    st.stop()
stop_words = set(stopwords.words('english'))

# Text cleaning function
def clean_text(text):
    if isinstance(text, str):
        text = re.sub(r'[^a-zA-Z\s]', '', text).lower()
        try:
            tokens = word_tokenize(text)
            tokens = [word for word in tokens if word not in stop_words]
            return ' '.join(tokens)
        except Exception as e:
            st.error(f"Tokenization failed: {str(e)}")
            return ''
    return ''

# Rule-based fake job detection
def detect_fake_job(text):
    suspicious_keywords = [
        'work from home', 'no experience needed', 'earn weekly', 'get rich quick',
        'immediate start', 'high pay', 'no skills required', 'easy money',
        'guaranteed income', 'limited spots'
    ]
    cleaned_text = clean_text(text).lower()
    if not cleaned_text:
        return None, None
    
    # Count suspicious phrases
    keyword_count = sum(1 for phrase in suspicious_keywords if phrase in cleaned_text)
    
    # Heuristic: More keywords = higher chance of fake
    if keyword_count >= 2:
        is_fake = 1  # Fake
        confidence_fake = min(90, 60 + keyword_count * 10)  # Pseudo-confidence
        confidence_real = 100 - confidence_fake
    else:
        is_fake = 0  # Real
        confidence_real = min(90, 70 - keyword_count * 10)
        confidence_fake = 100 - confidence_real
    
    return is_fake, (confidence_real / 100, confidence_fake / 100)

# Streamlit UI
st.title("Fake Job Posting Detector")
st.markdown("""
Welcome to the Fake Job Posting Detector! Paste a job posting below, and I'll predict whether it's **real** or **fake**. 
This tool analyzes text for suspicious patterns (note: this is a simplified rule-based version).
""")

# Input area
job_text = st.text_area("Enter the job posting text:", 
                        placeholder="E.g., Work from home, earn $5000 weekly, no experience needed!",
                        height=200, key="job_text")

# Predict button
if st.button("Check Job Posting"):
    if job_text.strip() == "":
        st.error("Please enter a job posting to analyze.")
    else:
        try:
            # Analyze input
            with st.spinner("Analyzing..."):
                prediction, confidence = detect_fake_job(job_text)
                
                if prediction is None:
                    st.error("Text processing failed. Please try again.")
                else:
                    prob_real, prob_fake = confidence
                    prob_fake *= 100
                    prob_real *= 100
                    
                    # Display results
                    if prediction == 1:
                        st.error("⚠️ This job posting is likely **FAKE**!")
                        st.markdown(f"**Confidence**: {prob_fake:.1f}% chance it's fake.")
                    else:
                        st.success("✅ This job posting seems **REAL**.")
                        st.markdown(f"**Confidence**: {prob_real:.1f}% chance it's real.")
                    
                    # Additional feedback
                    st.info("Note: This uses a rule-based approach. Always verify job postings through official channels.")
                
        except Exception as e:
            st.error(f"An error occurred during analysis: {str(e)}")

# Sidebar with info
st.sidebar.header("About")
st.sidebar.markdown("""
This app uses a rule-based system to detect fake job postings by looking for suspicious phrases 
like 'work from home' or 'no experience needed'. For a more accurate model, a trained machine learning system is recommended.
""")

st.sidebar.header("Tips")
st.sidebar.markdown("""
- Copy and paste the full job description for best results.
- Include details like title, requirements, and company info if available.
- Be cautious with postings promising high pay for little work!
""")

# Example button
if st.sidebar.button("Try an Example"):
    example_text = "Work from home, earn $5000 weekly, no experience needed! Immediate start."
    st.text_area("Enter the job posting text:", value=example_text, key="job_text", height=200)